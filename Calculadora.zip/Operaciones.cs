﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Operaciones

    {
        //constructores
        public Operaciones()
        { }
        public Operaciones(double nro)
        {
            this.nro1 = nro;
        }
        public Operaciones(double nro1, double nro2)
        {
            this.nro1 = nro1;
            this.nro2 = nro2;

        }

        //declarar atributos

        protected double nro1;
        protected double nro2;
        //propiedades

        public double Nro1
        {
            get { return this.nro1;}
            set { this.nro1 = value; }

        }

        public double Nro2
        {
            get { return this.nro1; }
            set { this.nro2 = value; }
         }

        //metodos operac¡iones

        public double Sumar()
        {
            return this.nro1 + this.nro2;

        }
        public double Restar()
        {
            return this.nro1 - this.nro2;

        }
        public double Multiplicar()
        {
            return this.nro1 * this.nro2;

        }
        public double Dividir()
        {
            return this.nro1 / this.nro2;

        }
        public double Raiz()
        {
            return Math.Sqrt(nro1);
        }
       public double Inverso()
        {
            return -this.nro1;
        }



    }
}
